function while1()
    return [[
x = 0
while x < 10 do
    x = x + 2 
    print(x)
end

return x
    ]]
end