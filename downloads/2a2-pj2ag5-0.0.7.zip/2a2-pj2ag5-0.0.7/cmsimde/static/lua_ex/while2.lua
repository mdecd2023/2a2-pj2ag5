function while2()
    return [[
while true do
  if condition then
    x = x ^ 2
  else
    break
  end
end
    ]]
end